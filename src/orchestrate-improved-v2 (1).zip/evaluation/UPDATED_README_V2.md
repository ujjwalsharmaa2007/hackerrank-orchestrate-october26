# Evidence reader update (v2)

Changes:
- Joins multi-line service log traces even when the initial lookup event has no resource_id.
- Reads active connector, restore eligibility, direct-identifier scan, and historical email-hash evidence.
- Corrects SQL integer 1/0 restore flags.
- Orders remediation by dependencies (disable flows, block restore, delete, redact, anonymize).
- Avoids presenting an earlier verification as definitive evidence when other resources remain incomplete.

Run:

    PYTHONPATH=src python evaluation/improved_sample_check.py
    PYTHONPATH=src python src/submission_generator.py

Observed sample results: 27/32 status classifications and 5/32 exact step sequences.

WARNING: This is an incomplete heuristic baseline. It does not fully parse PDF and PNG evidence, and cannot prove absent resources that lack an identity linkage. Do not mistake structurally valid output for an accurate full audit.
