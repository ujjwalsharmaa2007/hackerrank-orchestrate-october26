"""Evidence-based, time-bounded deletion audit evaluator."""
import csv
from functools import lru_cache
from pathlib import Path
from audit_agent import detect_deletion_request
from identity_resolver import resolve_identity
from unified_evidence import get_subject_observations

DATASET=Path(__file__).resolve().parent.parent/'dataset'

@lru_cache(maxsize=1)
def identities():
    with (DATASET/'user_identities.csv').open(encoding='utf-8-sig',newline='') as f:
        return {r['user_id']:r for r in csv.DictReader(f)}

@lru_cache(maxsize=1)
def activities():
    with (DATASET/'system_activity.csv').open(encoding='utf-8-sig',newline='') as f:
        result={}
        for row in csv.DictReader(f):result.setdefault(row['resource_id'],[]).append(row)
    for rows in result.values():rows.sort(key=lambda r:r['event_time'])
    return result

PREFIX_POLICY={
    'account':('DELETE','account_service'), 'search':('DELETE','search_service'),
    'export':('DELETE','export_service'), 'analytics':('ANONYMIZE','analytics_platform'),
    'support':('REDACT','support_platform'), 'audit_record':('RETAIN','security_service'),
    'data_flow':('DISABLE_FLOW','integration_service'), 'backup':('BLOCK_RESTORE','backup_service'),
    'tombstone':('REDACT','account_service')
}

def resource_policy(resource_id,observations):
    prefix=next((p for p in sorted(PREFIX_POLICY,key=len,reverse=True) if resource_id.startswith(p+'_')),None)
    if prefix is None:return None
    action,system=PREFIX_POLICY[prefix]
    if prefix=='support':
        # An attachment exclusively owned by the subject can be deleted;
        # shared conversation text is normally redacted.
        if any('attachment' in str(o['collection_name']).lower() for o in observations):action='DELETE'
    return action,system


def observation_state(row, action):
    d = row['record']
    result = str(d.get('result','')).upper()
    event = str(d.get('event','')).lower()
    if result in ('NOT_FOUND','ABSENT','DELETED'):
        return 'ABSENT'
    if result in ('FOUND','PRESENT','ACTIVE','IDENTIFIABLE','EXPOSED_PII','HIT'):
        return 'ACTIVE' if action in ('DISABLE_FLOW','BLOCK_RESTORE') else 'PRESENT'
    if result in ('ANONYMIZED','REDACTED','DISABLED','BLOCKED'):
        return result
    for key in ('status_code','http_status'):
        if key in d:
            if str(d[key])=='404':return 'ABSENT'
            if str(d[key])=='200' and action=='DELETE':return 'PRESENT'
    if 'rows' in d:
        if str(d['rows'])=='0':return 'ABSENT'
        if str(d['rows']) not in ('0','null','None') and action in ('DELETE','RETAIN'):
            return 'PRESENT'
    if action=='BLOCK_RESTORE':
        for key in ('deletion_block','restore_blocked'):
            if key in d:
                return 'BLOCKED' if str(d[key]).lower() in ('true','1') else 'ACTIVE'
        for key in ('restore_allowed','eligible'):
            if key in d:
                return 'ACTIVE' if str(d[key]).lower() in ('true','1') else 'BLOCKED'
    if action=='DISABLE_FLOW':
        if str(d.get('enabled','')).lower() in ('false','0'):return 'DISABLED'
        if str(d.get('enabled','')).lower() in ('true','1'):return 'ACTIVE'
    if action=='ANONYMIZE':
        fields=('user_id','customer_reference','email','phone','email_hash')
        values=[d.get(k) for k in fields if k in d]
        if values:
            return 'ANONYMIZED' if all(v is None or str(v).lower() in ('','null','[redacted]') for v in values) else 'PRESENT'
        if 'matched_value' in d or 'direct_identifiers' in d:return 'PRESENT'
    if action=='REDACT':
        fields=('requester_email','requester_name','requester_phone','email','phone','full_name')
        values=[d.get(k) for k in fields if k in d]
        if values:
            return 'REDACTED' if all(v is None or str(v).lower() in ('','null','[redacted]') for v in values) else 'PRESENT'
        if 'matched_value' in d or 'direct_identifier' in event:return 'PRESENT'
    if action=='DELETE':
        if d.get('resource_id') and ('scan' in event or 'query' in event or 'lookup' in event):return 'PRESENT'
        if d.get('resource_id') and not event:return 'PRESENT'
    if action=='RETAIN' and d.get('resource_id'):return 'PRESENT'
    return None

STEP_TYPES={
 'DELETE':(('REPORT_REMAINING_RECORD','PRESENT'),('DELETE_RECORD','ABSENT'),('VERIFY_RECORD_ABSENT','ABSENT')),
 'REDACT':(('REPORT_EXPOSED_PII','PRESENT'),('REDACT_RECORD','REDACTED'),('VERIFY_RECORD_REDACTED','REDACTED')),
 'ANONYMIZE':(('REPORT_EXPOSED_PII','PRESENT'),('ANONYMIZE_RECORD','ANONYMIZED'),('VERIFY_RECORD_ANONYMIZED','ANONYMIZED')),
 'DISABLE_FLOW':(('REPORT_ACTIVE_DATA_FLOW','ACTIVE'),('DISABLE_DATA_FLOW','DISABLED'),('VERIFY_DATA_FLOW_DISABLED','DISABLED')),
 'BLOCK_RESTORE':(('REPORT_RESTORE_RISK','ACTIVE'),('BLOCK_RESTORE','BLOCKED'),('VERIFY_RESTORE_BLOCKED','BLOCKED')),
 'RETAIN':(None,None,('VERIFY_RECORD_PRESENT','PRESENT'))
}

def evaluate_case(request):
    if not detect_deletion_request(request['request_text']):return 'NOT_APPLICABLE',[]
    identity=resolve_identity(request['email'])
    user=next((identities().get(uid) for uid in identity['user_ids'] if uid in identities()),None)
    rows=get_subject_observations(identity,request['audit_at'],user)
    groups={}
    for row in rows:groups.setdefault(row['resource_id'],[]).append(row)
    findings=[];remediations=[];verifications=[]
    # Order by operational dependency: stop live flows, remove direct copies,
    # redact shared records, anonymize analytics, then verify.
    order={'account':0,'search':1,'export':2,'support':3,'analytics':4,
           'audit_record':5,'tombstone':6,'data_flow':7,'backup':8}
    def key(resource_id):
        prefix=next((p for p in order if resource_id.startswith(p+'_')),None)
        return (order.get(prefix,99),resource_id)
    for resource_id,observations in sorted(groups.items(),key=lambda kv:key(kv[0])):
        policy=resource_policy(resource_id,observations)
        if not policy:continue
        action,system=policy
        observations.sort(key=lambda r:(r['observed_at'],r['captured_at']))
        state_obs=[(observation_state(r,action),r) for r in observations]
        state_obs=[(st,r) for st,r in state_obs if st]
        if not state_obs:continue
        state,evidence=state_obs[-1]
        expected={'DELETE':'ABSENT','REDACT':'REDACTED','ANONYMIZE':'ANONYMIZED',
                  'RETAIN':'PRESENT','DISABLE_FLOW':'DISABLED','BLOCK_RESTORE':'BLOCKED'}[action]
        finding,remediation,verification=STEP_TYPES[action]
        def step(phase,operation_state,evidence_id):
            op,st=operation_state
            return {'step_no':0,'phase':phase,'system_id':system,'resource_id':resource_id,
                    'operation':op,'state':st,'evidence_id':evidence_id}
        if state!=expected and action!='RETAIN':
            if finding:findings.append(step('FINDING',finding,evidence['evidence_id']))
            if remediation:remediations.append(step('REMEDIATION',remediation,''))
            verifications.append(step('VERIFICATION',verification,''))
        else:
            verifications.append(step('VERIFICATION',verification,evidence['evidence_id']))
    incomplete=bool(findings)
    if not groups:
        return 'INCOMPLETE',[]
    # Findings follow the user-facing data lineage. Remediation is ordered by
    # dependency, and verification follows that same lineage.
    def fkey(st):return key(st['resource_id'])
    findings.sort(key=fkey)
    remediations.sort(key=lambda st:(0 if st['operation']=='DISABLE_DATA_FLOW' else
                                  1 if st['operation']=='BLOCK_RESTORE' else
                                  2 if st['operation']=='DELETE_RECORD' else
                                  3 if st['operation']=='REDACT_RECORD' else 4,
                                  key(st['resource_id'])))
    verifications.sort(key=fkey)
    if incomplete:
        for st in verifications:st['evidence_id']=''
    steps=findings+remediations+verifications
    for n,st in enumerate(steps,1):st['step_no']=n
    return ('INCOMPLETE' if incomplete else 'COMPLETE'),steps
